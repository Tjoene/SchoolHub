##Tutorials##

 * http://crunchify.com/simplest-spring-mvc-hello-world-example-tutorial-spring-model-view-controller-tips/
 * http://www.tutorialspoint.com/spring/spring_exception_handling_example.htm

##Installed software##

API Tools Execution Environment Descriptions
C/C++ Development Tools
C/C++ Development Tools SDK
ChangeLog Management Tools
Code Recommenders Mylyn Integration
Data Tools Platform Enablement Extender SDK
Eclipse Data Tools Platform
Data Tools Platform Extender SDK
Eclipse IDE for Java Developers
Eclipse Java EE Developer Tools
Eclipse Java Web Developer Tools
Eclipse JDT Plug-in Developer Resources
Eclipse Web Developer Tools
JavaScript Development Tools
JSF Tools
JST Server Adapters
JST Server Adapters Extensions
JST Server UI
m2e - Extensions Development Support (Optional)
m2e connector for mavenarchiver pom properties
Remote Services
UML2 Extender SDK